# CVM Labs — starter website

A lightweight, responsive dark landing page for the proposed brand of Collins Vincent Macharia.

## Important
- `CVM Labs` is a provisional name, not verified as legally available or registered.
- This is a static brand website prototype. It does not yet connect to an AI model or collect user data.
- No paid domain, framework, or build step is required.

## Publish free with GitHub Pages using an Android phone
1. Open https://github.com in your browser and sign in.
2. Create a **public** repository named `cvm-labs-site`.
3. Add a file named `index.html`.
4. Open the included `index.html`, copy all its contents, and paste into GitHub's editor for `index.html`.
5. Commit the changes.
6. In the repository, open **Settings → Pages**.
7. Under Build and deployment, choose **Deploy from a branch**, branch `main`, folder `/(root)`, then Save.
8. Wait for GitHub Pages to publish and open the URL shown on that Pages screen.

## Before public launch
- Confirm the brand name through Kenya's Business Registration Service and check relevant trademarks.
- Replace or edit any wording that doesn't accurately describe your work yet.
- Add only a public business email/contact method you choose to publish.
- Build and test a real first product before describing it as launched.
